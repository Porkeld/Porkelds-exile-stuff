//GOM_fnc_aircraftLoadout V1.34 made by Grumpy Old Man 17-5-2017


class Aircraft_Loadouts
{

	class init

	{

		class aircraftLoadoutParameters{file = "scripts\Aircraft_Loadouts\functions\GOM_fnc_aircraftLoadoutParameters.sqf";preInit = 1;};
		class aircraftLoadoutInit{file = "scripts\Aircraft_Loadouts\functions\GOM_fnc_aircraftLoadoutInit.sqf";preInit = 1;};

	};

};
