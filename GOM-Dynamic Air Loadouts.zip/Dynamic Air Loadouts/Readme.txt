//GOM_fnc_aircraftLoadout V1.34 made by Grumpy Old Man 17-5-2017
// Ported over to Exile By Jason "Punisher" Mayr
/*
feel free to use as you like, as long as I'm credited as the original author

works on dedi and MP

Note that it is advisable to repair an aircraft before refuelling it, since a damaged aircraft can leak fuel down to a certain level.
This is vanilla A3 functionality and nothing I can do about here.

Functions for missionmakers:

	Empty all pylons: [YourAircraftName] call GOM_fnc_clearAllPylons;
	Set tail number: [YourAircraftName,"123"] call GOM_fnc_aircraftSetSerialNumber; //only accepts 3 digit string for gryphon, shikra and black wasp

	//these commands allow you to add ammo, fuel or repair cargo to any vehicle
	//with this you can have a HQ building holding these resources or have a hemtt(box) holding all 3 resource types, up to you, range check still applies
	//also possible to override the default max. capacity of 10000kg/l per vehicle
	Set repair cargo:[YourVehicle,2500] call GOM_fnc_setRepairCargo; //will set the vehicles repair cargo to 2500kg
	Set fuel cargo:[YourVehicle,2500] call GOM_fnc_setFuelCargo; //will set the vehicles fuel cargo to 2500l
	Set repair cargo:[YourVehicle,2500] call GOM_fnc_setAmmoCargo; //will set the vehicles ammo cargo to 2500kg

	_add = [this] spawn GOM_fnc_addAircraftLoadout; //put this into the initPlayerLocal.sqf of your mission root folder if you want every player to have access to this menu
	//you can further restrict access to this menu by filtering for UID or player objects, but this is entirely up to you how to implement it, a peek into the initPlayerLocal.sqf of this mission can be one possibility

	_add = this spawn GOM_fnc_addAircraftLoadoutToObject; //put this into the init field of an object to have the object grant access to the loadout menu
	//see the mission for further examples

List of commands used by remoteExec:

SetPylonLoadout
SetAmmoOnPylon
removeWeaponGlobal
setPylonsPriority
GOM_fnc_handleResources
setFuelCargo
setAmmoCargo
setRepairCargo
setFuel

Changelog:

V1.34
Fixed: Proper removal of weapons if not used by other pylons

V1.33
Few tweaks and locality related stuff

V1.32
(HOTFIX) Fixed yet another variable error

V1.31
(HOTFIX) Fixed variable error
Added: Check if the aircraft is leaking fuel, and stop refueling until up to the point where the leak occurs.

V1.3
Added: Resource handling
	Repairing, refueling and rearming will now deplete the resources of the respective vehicles
	Mission makers can use functions to add resources to vehicles, maybe as a reward for completing a mission or whatever comes to your mind
Added: The three digit serial (tail) number of the aircraft can be changed, if supported by the model (currently working on: Gryphon, Shikra and Black Wasp)
	After selecting the aircraft enter the 3 digit number you want into the same field that's used to set the ammo amount for the pylons
	Numbers like 5,6 are mirrored on the shirka, that's up on BI or the DLC dev to fix
Added: Pylon priority setting
	Pylon priorities will be displayed in the info panel
	Weapons on multiple pylons sharing the same priority will be listed as one weapon
	Priority button usage:
		LMB = Increase priority of currently selected pylon by 1
		Shift+LMB = Decrease priority of currently selected pylon by 1
		Alt+LMB = Set all pylons to the currently set priority
		Ctrl+LMB = Set all pylons to priority 1
		The priority will be set to the currently selected pylon when clicking the priority button
		Selecting another pylon will display its current priority on the button
Added: Tons of functionality for the text display, loadout changes and resource changes will be displayed in realtime
	-Click on aircraft -> shows fuel/damage state, now also tracks kills made by the vehicle and successful landings
	-Click on pylon -> shows current loadout+ammo count for each pylon
	-Click on weapon -> shows installation details on what weapon will be installed on what pylon, who operates it and weapon details
	-Click on "Show Resources" Button -> will display all available supplies, their amounts and types, if the resource management is active
	Upon closing the dialog all nearby supplies will display their current resource cargo value for 20 seconds
Changed: Weapon listbox is now sorting all weapons alphabetically
Changed: The aircraft loadout function will be reapplied upon respawn
Changed: Moved loadout menu to the communication menu for players (default: 0 - 8 - 1)
Changed: Function to add the loadout menu to a vehicle MP and dedi compatible
Changed: Rearming sound will be positional for each pylon
Changed: Rearming the plane will no longer empty all pylons, and just fill up the existing pylons instead
Changed: The menu now updates in real time, new planes within range will be displayed as soon as they are stationary and on the ground, same goes for resource vehicles if the option is enabled. So you no longer need to reOpen the dialog if any of these change
Fixed: Pylons were not properly updated on dedicated

todo:

demo mission containing examples on how to:
	add a aircraft service zone (trigger + resource vehicles)
	handle resources for mission makers


V1.24
(HOTFIX) Fixed further dialog shenanigans (thanks @Teuf)

V1.23
(HOTFIX) Renamed the last remaining dialog parent classes, heh.

V1.22
(HOTFIX) Renamed dialog parents classes to prevent conflicts with other scripts (thanks @sarogahtyp)

V1.21
(HOTFIX) Changed the description.ext and cfgFunctions part to avoid issues with other scripts that are using this feature
Fixed error being unable to use repair/rearm/refuel with resource dependencies disabled
Adjusted startup text info

V1.2
Added button to select who has control over the pylon (pilot or gunner)
Added customer presets saved individually for each vehicle for every player
 -Presets will be saved for each vehicle type, so you can equip multiple aircraft with the same loadout within a few clicks
 -Presets will contain the pylon loadout, ammo amount from each pylon, respective pylon owners (pilot, gunner) and the livery of the aircraft
 -Presets are stored in profileNamespace, so they'll persist everytime you use this loadout menu, no matter which server you're on
 -Delete button is locked by default, can only be used when holding CTRL to prevent mishaps
Added livery option, will change texture if the aircraft has any in the config
Added option to override the pylon compatibility check, yay 120 DAGR wipeout
Added option to make the presence of ammo/fuel/repair supplies necessary, no ammotruck? no fancy weapons!
Added duration to rearming an aircraft, fully rearming an empty 120 DAGR wipeout can take up to 2 minutes
Added duration to repairing an aircraft, default is set to 60s from 0 to 100% health
 -repair speed can be adjusted
Added duration to refuelling an aircraft, fillrate is set to 1800l/min as default and will be calculated accordingly (wipeout with 1000l fuel capacity will take 33s to refill to 100%)
 -refill rate can be adjusted
 -refuelling will abort when the aircraft is not stationary
 -you can only simultaneously refuel as much airplanes as you have fuel sources
Fixed 'clear all pylons' button now to properly remove all leftover weapon classes from the aircraft
Fixed 'rearm' button now to properly rearm all weapons, on board cannons, flare/chaff launchers


V1.1
Added compatibility check for magazines and pylons, so you can't add everything on every pylon.
Installing a pylon takes some time.
Added possibility to execute this for one pilot in a stationary aircraft or as an action from an ammo truck or whatever you'd like.
Added options for reporting and receiving of remote targets as well as reporting the aircrafts own position.
The 'clear all pylons' button now properly removes all pylons, no more leftovers

Files needed:
\scripts\GOM\dialogs\GOM_dialog_controls.hpp
\scripts\GOM\dialogs\GOM_dialog_parents.hpp
\scripts\GOM\functions\GOM_fnc_aircraftLoadoutInit.sqf
\scripts\GOM\functions\GOM_fnc_aircraftLoadoutParameters.sqf //adjust parameters here
\scripts\GOM\functions\GOM_fnc_functions.hpp
\description.ext

example if you want to limit by UID Number (really never used)

//GOM_fnc_aircraftLoadout V1.34 made by Grumpy Old Man 17-5-2017

//this is just an example and this file is not needed at all
//see the main file description for further details
params ["_unit","_JIP"];

if (_unit getvariable ["GOM_fnc_aircraftLoadoutAllowed",false]) then {

	_unit spawn GOM_fnc_addAircraftLoadout;

};

Exile Port by Jason "Punisher" Mayr

Version 1.0
UN PBO your mision file and follow the steps below:

Added the Scripts folder to you mpmissions\exile.<MAP> folder

open the Description file and add the contents the one in the mission folder.

Open the Config.cpp and add the contents to the Config.cpp in the mission folder.

Add below to the class CfgRemoteExec:

Save the Mission file and Re PBO 

*/

		class SetPylonLoadout										{ allowedTargets=2; };
		class SetAmmoOnPylon										{ allowedTargets=2; };
		class removeWeaponGlobal									{ allowedTargets=2; };
		class setFuel												{ allowedTargets=2; };
		class setPylonsPriority										{ allowedTargets=2; };
		class GOM_fnc_handleResources								{ allowedTargets=2; };
		class setFuelCargo											{ allowedTargets=2; };
		class setAmmoCargo											{ allowedTargets=2; };
		class setRepairCargo										{ allowedTargets=2; };

