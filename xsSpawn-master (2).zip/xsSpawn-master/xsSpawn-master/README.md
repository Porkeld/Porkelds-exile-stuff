# xsSpawn
Ground Spawn or Halo Selection for Exile

What is it?
It is a custom spawn selection screen that replaces the default exile spawn selection and it gives you the option to either halo spawn or ground spawn.
You can also add your server logo and custom messeages to be displayed when your players spawn, like important announcments or server tips.
