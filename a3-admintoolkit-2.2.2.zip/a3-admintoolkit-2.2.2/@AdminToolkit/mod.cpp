name = "Admin Toolkit [v2.2.2]";
author = "ole1986";
actionName = "Website";
action = "https://github.com/ole1986/a3-admintoolkit";
