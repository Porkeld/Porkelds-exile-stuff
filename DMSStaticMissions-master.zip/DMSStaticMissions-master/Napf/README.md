# DMSStaticMissions
Exile DMS Napf Static Missions


*******************************************************
	Static missions for Napf.
	Credits to Pradatoru for some mapping
	Created by [CiC]red_ned using templates by eraser1 
	19 years of CiC http://cic-gaming.co.uk
*******************************************************
	Each is map specific
	Running on DMS System
*******************************************************
You must have DMS installed