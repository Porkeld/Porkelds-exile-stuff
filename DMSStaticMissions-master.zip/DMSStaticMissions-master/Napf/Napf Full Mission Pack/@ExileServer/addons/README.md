To install

1. Merge object/mission files into your DMS PBO file.
2. Merge the config.sqf into your config file (its just the DMS_StaticMissionTypes section to be replaced).
3. Repack and move onto a3_custom.pbo

You can use the provided a3_custom.pbo file or change things in the @ExileServer\addons\a3_custom\init\fn_init.sqf file to stop loading the files or merge with your own custom mapping

4. both pbo files should just be added to your @ExileServer\addons\ folder on the server.