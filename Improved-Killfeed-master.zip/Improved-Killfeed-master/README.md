/*

Improved Killfeed for ExileMod (Exile 1.0.2)

by [FPS]kuplion

http://www.friendlyplayershooting.com

*/