# DMS Bandit Zombie Themed Missions Pack<br>
<b> Original thread http://www.exilemod.com/topic/12072-update32-dms-bandit-missions-either-new-or-reworked/?page=1 </b><br>
>>	Templates and original stock missions created by Defent and eraser1<br>
>>	easy/mod/difficult/hardcore - reworked by [CiC]red_ned http://cic-gaming.co.uk<br>
>>	Missions spreadsheet with their setups here: https://drive.google.com/open?id=1wy-j9QHf1ZTl_iK01raut-xZ8p9ulDHf506vkFgyieU <br>
>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

<b>Updated 16 July 2016 > V 3.0a - Release</b><br>
This is just some extra missions reworked to run custom AI rather than standard bandits.<br>
The mission theme was asked for and so a scientist kind of feel is used but you can adjust missions easily with custom costumes and mission messages<br>
<b>This is a zombie feel, and does not contain zombies as DMS does not support them but just feels a little more like a zombie server may use</b>
