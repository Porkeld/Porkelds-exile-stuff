# BETA DMS ZOMBIE Missions
<b>You need RyanZombies installed</b><br>
<b> Original thread http://www.exilemod.com/topic/12072-update32-dms-bandit-missions-either-new-or-reworked/?page=1 </b><br>
>>	Templates and original stock missions created by Defent and eraser1<br>
>>	easy/mod/difficult/hardcore - reworked by [CiC]red_ned http://cic-gaming.co.uk<br>
>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

<b>Beta selection of missions which use zombies inside the DMS system</b><br>
All missions in BETA are pre-testing or in developing states <br>
Code may not be complete to a finished shine <br>
Anything that isnt in a working state will be commented <br>
This is the first script to try to test zombies and is very simple <br>

<b>Not recommended for live servers</b><br>
Please report any BETA mission issues or comments (especially if they are working) so i can add them to the live package<br>
<br><br>
*******************************************************
Installing.
1. 	Copy contents of this folder>/missions/bandit/ into a3_dms.pbo /missions/bandit/ , you can remove old missions.<br>
2. 	no buildings in test mission<br>
3. 	Extract main config.sqf<br>
4.	Find	DMS_BanditMissionTypes = [ <br>
5.	Add to the list betweeen []; (remembering to add a comma to all but the last line)<br>
["nedztest",3]<br>										
6.	Repack config.sqf and folders into PBO<br>
7. 	Put a3_dms.pbo back into /@ExileServer/addons/ on server and start.<br>
<br>
No BE or InfiSTAR additions apart from what you installed to run DMS. <b>This will not run without DMS and RyanZombies.</b> <br>