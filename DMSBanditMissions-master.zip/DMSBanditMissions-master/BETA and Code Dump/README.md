# BETA DMS Bandit Missions
<br>
<b> Original thread http://www.exilemod.com/topic/12072-update32-dms-bandit-missions-either-new-or-reworked/?page=1 </b><br>
>>	Templates and original stock missions created by Defent and eraser1<br>
>>	easy/mod/difficult/hardcore - reworked by [CiC]red_ned http://cic-gaming.co.uk<br>
>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

<b>Beta selection of missions</b><br>
All missions in BETA are pre-testing or in developing states <br>
Code may not be complete to a finished shine <br>
Anything that isnt in a working state will be commented <br>
Some of this stuff is just code dumped for reference <br>

<b>Not recommended for live servers</b><br>
Please report any BETA mission issues or comments (especially if they are working) so i can add them to the live package<br>
