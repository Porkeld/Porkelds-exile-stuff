# Code Dump
<br>
<b> Original thread http://www.exilemod.com/topic/12072-update32-dms-bandit-missions-either-new-or-reworked/?page=1 </b><br>
>>	Templates and original stock missions created by Defent and eraser1<br>
>>	easy/mod/difficult/hardcore - reworked by [CiC]red_ned http://cic-gaming.co.uk<br>
>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

<b>Code dumps of things i found from around the internet which help build missions</b><br>
All code belongs to the original author and i will try to credit where i can<br>
Code may not be complete <br>
Bits of code i have used and explained stuff will be dropped here for reference <br>


<b>Kind of useful sometimes for bits and pieces of code</b><br>
If anything belongs to you and you would like it removed or accredited then let me know via Exile forums<br>
