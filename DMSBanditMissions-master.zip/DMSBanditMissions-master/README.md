# DMS Bandit Missions v4.0
DMS Bandit Missions Pack<br>
<b> Original thread http://www.exilemod.com/topic/12072-update32-dms-bandit-missions-either-new-or-reworked/?page=1 </b><br>
>>	Templates and original stock missions created by Defent and eraser1<br>
>>	easy/mod/difficult/hardcore - reworked by [CiC]red_ned http://cic-gaming.co.uk<br>
>>	Missions spreadsheet with their setups here: https://drive.google.com/open?id=1wy-j9QHf1ZTl_iK01raut-xZ8p9ulDHf506vkFgyieU <br>
>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

<b>Updated June 2018 > V4.0 - Release</b><br>
Now with rocket and mine chance - mines cleaned on mission win<br>
Mines clear up on mission win<br>
Big tidy on code to make it more easy to edit<br>
Missions should automatically over ride DMS configuration file settings<br>
<br><br>

<b>Updated 25 March 2017 > V3.1 - Beta Section Added</b><br>
Added a beta section for testing missions along with code dumps. <br>

<b>Updated 14 March 2017 > V3.1 - Release</b><br>
<b>Updated 10 March 2017 > V3.1 - Release</b><br>
<b>Updated 16 July 2016 > V 3.0 - Release</b><br>
<b>Updated 14 June 2016 > V 2.0 - Release</b><br>
<b>Update 12 April > V 1.1 - Release</b><br>
<b>Updates March 2016 > V 1.0 - Release</b><br>
