	///////////////////////////////////////////////////////////////////////////////
	// Arma 3 Jets DLC
	//////////////////////////////////////////////////////////////////////////////

	///////////////////////////////////////////////////////////////////////////////
	// Planes
	//////////////////////////////////////////////////////////////////////////////
	class I_Plane_Fighter_04_F						{ quality = 1; price = 550000; };
	class B_Plane_Fighter_01_Stealth_F				{ quality = 1; price = 550000; };
	class B_Plane_Fighter_01_F						{ quality = 1; price = 550000; };
	class O_Plane_Fighter_02_F						{ quality = 1; price = 550000; };
	class O_Plane_Fighter_02_Stealth_F				{ quality = 1; price = 550000; };

	///////////////////////////////////////////////////////////////////////////////
	// Jets DLC items
	///////////////////////////////////////////////////////////////////////////////
	class V_DeckCrew_blue_F							{ quality = 2; price = 30; };
	class V_DeckCrew_brown_F						{ quality = 2; price = 30; };
	class V_DeckCrew_green_F						{ quality = 2; price = 30; };
	class V_DeckCrew_red_F							{ quality = 2; price = 30; };
	class V_DeckCrew_violet_F						{ quality = 2; price = 30; };
	class V_DeckCrew_white_F						{ quality = 2; price = 30; };
	class V_DeckCrew_yellow_F						{ quality = 2; price = 30; };