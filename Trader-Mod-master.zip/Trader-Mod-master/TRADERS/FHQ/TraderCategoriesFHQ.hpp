	class FHQACCESSORIES
	{
		name = "FHQ ACCESSORIES";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] =
		{
			"FHQ_acc_ANPEQ15",
			"FHQ_acc_ANPEQ15_black",
			"FHQ_acc_LLM01F",
			"FHQ_acc_LLM01L",
			"FHQ_optic_AC11704",
			"FHQ_optic_AC11704_tan",
			"FHQ_optic_AC12136",
			"FHQ_optic_AC12136_tan",
			"FHQ_optic_ACOG",
			"FHQ_optic_ACOG_tan",
			"FHQ_optic_AIM CompM4",
			"FHQ_optic_AIM_tan",
			"FHQ_optic_AimM_BLK",
			"FHQ_optic_AimM_TAN",
			"FHQ_optic_HWS",
			"FHQ_optic_HWS_G33",
			"FHQ_optic_HWS_G33_tan",
			"FHQ_optic_HWS_tan",
			"FHQ_optic_LeupoldERT",
			"FHQ_optic_LeupoldERT_tan",
			"FHQ_optic_MARS",
			"FHQ_optic_MARS_tan",
			"FHQ_optic_MCCO_M_BLK",
			"FHQ_optic_MCCO_M_TAN",
			"FHQ_optic_MicroCCO",
			"FHQ_optic_MicroCCO_low",
			"FHQ_optic_MicroCCO_low_tan",
			"FHQ_optic_MicroCCO_tan",
			"FHQ_optic_TWS3050",
			"FHQ_optic_VCOG",
			"FHQ_optic_VCOG_tan"
		};
	};

