	///////////////////////////////////////////////////////////////////////////////
	// NLD MOD
	// Thanks to its Dutch and John MCSwagatron PORN Exile for update of items
	///////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////
	// NLD Units
	///////////////////////////////////////////////////////////////////////////////
	//jets
	class NLD_F16C_AA								{ quality = 6; price = 6000000; };
	class NLD_F16C_CAS								{ quality = 6; price = 6000000; };
	class NLD_F16C_CASAI							{ quality = 6; price = 6000000; };
	//tanks                             
	class NLD_WLD_Leo2								{ quality = 6; price = 5000000; };
	class NLD_ORANGE_Leo2							{ quality = 6; price = 5000000; };
	class NLD_DST_Leo2								{ quality = 6; price = 5000000; };
	//class NLD_WLD_PzH2000NL						{ quality = 6; price = 6000000; };
	//class NLD_WLD_M270MLRS						{ quality = 6; price = 6000000; };
	class NLD_WLD_CV9035NL							{ quality = 6; price = 3000000; };
	class NLD_DST_CV9035NL							{ quality = 6; price = 3000000; };
	class NLD_WLD_YPR								{ quality = 6; price = 600000; };
	class NLD_KMAR_YPR								{ quality = 6; price = 600000; };
	class NLD_KMAR_Buffel							{ quality = 6; price = 600000; };
	class NLD_WLD_Buffel							{ quality = 6; price = 600000; };
	class NLD_WLD_PRTL								{ quality = 6; price = 5000000; };
	//Vehicle
	class NLD_DST_Fennek							{ quality = 3; price = 50000; };
	class NLD_DST_Fennek_HMG						{ quality = 3; price = 250000; };
	class NLD_DST_Fennek_GMG						{ quality = 3; price = 250000; };
	class NLD_DST_VECTOR_ARMED						{ quality = 3; price = 50000; };
	class NLD_DST_VECTOR							{ quality = 3; price = 25000; };
	class NLD_WLD_Fennek							{ quality = 3; price = 50000; };
	class NLD_WLD_Fennek_HMG						{ quality = 3; price = 250000; };
	class NLD_WLD_Fennek_GMG						{ quality = 3; price = 250000; };
	class NLD_WLD_VECTOR							{ quality = 3; price = 25000; };
	class NLD_WLD_VECTOR_ARMED						{ quality = 3; price = 100000; };
	class NLD_WTR_Fennek							{ quality = 3; price = 50000; };
	class NLD_WTR_Fennek_HMG						{ quality = 3; price = 250000; };
	class NLD_WTR_Fennek_GMG						{ quality = 3; price = 250000; };
	class NLD_DAF_Transport_Covered					{ quality = 3; price = 25000; };
	class NLD_DAF_Transport							{ quality = 3; price = 25000; };
	class NLD_DAF_Fuel								{ quality = 3; price = 25000; };
	class NLD_DAF_repair							{ quality = 3; price = 25000; };
	class NLD_DAF_ammo								{ quality = 3; price = 300000; };
	class NLD_DAF_medical							{ quality = 3; price = 25000; };
	//Helicopter
	class EC635_NLD_Police							{ quality = 3; price = 50000; };
	class EC635_NLD_Lifeliner						{ quality = 3; price = 50000; };
	//class NLD_AH64D								{ quality = 3; price = 2200000; };// sidewinders are bugged
	class NLD_Lynx_Armed							{ quality = 3; price = 2000000; };
	class NLD_Lynx									{ quality = 3; price = 50000; };
	class NLD_Lynx_Hellfire							{ quality = 3; price = 2500000; };
	class NLD_Lynx_Cannon							{ quality = 3; price = 2000000; };
	class NLD_NH90									{ quality = 3; price = 50000; };
	class NLD_CH47D_Armed							{ quality = 3; price = 50000; };
	class NLD_CH47F_Armed							{ quality = 3; price = 50000; };
	class NLD_CH47_Armed							{ quality = 3; price = 50000; };
	class NLD_CH47_Unarmed							{ quality = 3; price = 50000; };
	///////////////////////////////////////////////////////////////////////////////
	// NLD Clothing
	///////////////////////////////////////////////////////////////////////////////
	//backpacks
	class NLD_WTR_Carryall_Empty 					{ quality = 1; price = 15000; };
	class NLD_SF_Carryall_Empty						{ quality = 1; price = 15000; };
	class NLD_KM_Carryall_Empty						{ quality = 1; price = 15000; };
	class NLD_Spongebob_Tactical					{ quality = 1; price = 15000; };
	class NLD_80_Fieldpack_Empty					{ quality = 1; price = 15000; };
	//clothing
	class NLD_WLD_Camo								{ quality = 1; price = 10000; };
	class NLD_DST_Camo								{ quality = 1; price = 10000; };
	class NLD_NFPT_Camo								{ quality = 1; price = 10000; };
	class NLD_NFPG_Camo								{ quality = 1; price = 10000; };
	class NLD_WTR_Camo								{ quality = 1; price = 10000; };
	class NLD_JGL_Camo								{ quality = 1; price = 10000; };
	class NLD_SF_CAMO								{ quality = 1; price = 10000; };
	class NLD_MTP_CAMO								{ quality = 1; price = 10000; };
	class NLD_MTP_CAMO2								{ quality = 1; price = 10000; };
	class NLD_KM_Camo								{ quality = 1; price = 10000; };
	class NLD_KM_Camo2								{ quality = 6; price = 10000; };
	class NLD_Police_Uniform						{ quality = 1; price = 10000; };
	class NLD_Lifeliner_Uniform						{ quality = 1; price = 10000; };
	class NLD_KMAR_Camo								{ quality = 1; price = 10000; };
	class NLD_KMAR_Camo2							{ quality = 1; price = 10000; };
	class NLD_KMAR_Crew_Camo						{ quality = 1; price = 10000; };
	class NLD_Units_80_Camo							{ quality = 1; price = 10000; };
	class NLD_Units_80_Camo2						{ quality = 1; price = 10000; };
	class NLD_Units_80_Camo3						{ quality = 1; price = 10000; };
	//vest
	class NLD_WLD_Vest								{ quality = 1; price = 10000; };
	class NLD_NFPT_Vest								{ quality = 1; price = 10000; };
	class NLD_NFPG_Vest								{ quality = 1; price = 10000; };
	class NLD_DST_Vest								{ quality = 1; price = 10000; };
	class NLD_WTR_Vest								{ quality = 1; price = 10000; };
	class NLD_SF_Vest								{ quality = 1; price = 10000; };
	class NLD_JGL_Vest								{ quality = 1; price = 10000; };
	class NLD_UN_Vest								{ quality = 1; price = 10000; };
	class NLD_SF_PlateCarrier						{ quality = 1; price = 10000; };
	class NLD_MTP_PlateCarrier						{ quality = 1; price = 10000; };
	class NLDO_KMAR_Vest							{ quality = 1; price = 10000; };
	class NLD_80_Chestrig							{ quality = 1; price = 10000; };
	class NLD_Police_belt							{ quality = 1; price = 10000; };
	//helmet
	class NLD_WLD_Helmet							{ quality = 1; price = 5000; };
	class NLD_DST_Helmet							{ quality = 1; price = 5000; };
	class NLD_NFPT_Helmet							{ quality = 1; price = 5000; };
	class NLD_NFPG_Helmet							{ quality = 1; price = 5000; };
	class NLD_WTR_Helmet							{ quality = 1; price = 5000; };
	class NLD_KM_Helmet								{ quality = 1; price = 5000; };
	class NLD_JGL_Helmet							{ quality = 1; price = 5000; };
	class NLD_UN_Helmet								{ quality = 1; price = 5000; };
	class NLD_WLD_Helmet_Camo						{ quality = 1; price = 5000; };
	class NLD_SF_ECH								{ quality = 1; price = 5000; };
	class NLD_MTP_ECH								{ quality = 1; price = 5000; };
	class NLD_Police_Helmet							{ quality = 1; price = 5000; };
	class NLD_Lifeliner_Helmet						{ quality = 1; price = 5000; };
	class NLD_KMAR_Helmet							{ quality = 1; price = 5000; };
	class NLD_M1Helmet_Green						{ quality = 1; price = 5000; };
	class NLD_ProTecHelmet_Black					{ quality = 1; price = 5000; };
	class NLD_ProTecHelmet_Green					{ quality = 1; price = 5000; };
	class NLD_ProTecHelmet_Tan						{ quality = 1; price = 5000; };
	class NLD_WLD_BoonieHat							{ quality = 1; price = 5000; };
	class NLD_DST_BoonieHat							{ quality = 1; price = 5000; };
	class NLD_NFPT_BoonieHat						{ quality = 1; price = 5000; };
	class NLD_NFPG_BoonieHat						{ quality = 1; price = 5000; };
	class NLD_SF_BoonieHat							{ quality = 1; price = 5000; };
	class Dutch_Beret_RoyalMarines					{ quality = 1; price = 5000; };
	class Dutch_Beret_Commandos						{ quality = 1; price = 5000; };
	class Dutch_Beret_KMAR							{ quality = 1; price = 5000; };
	class Dutch_Beret_80							{ quality = 1; price = 5000; };
	class Dutch_Beret_Luchtmobiele_Brigade			{ quality = 1; price = 5000; };

	///////////////////////////////////////////////////////////////////////////////
	// NLD WEAPONS
	///////////////////////////////////////////////////////////////////////////////
	class NLD_MX_DMR_W								{ quality = 1; price = 30000; };
	class NLD_MX_SW_W								{ quality = 1; price = 20000; };
	class NLD_MX_GL_W								{ quality = 1; price = 20000; };
	class NLD_MX_W									{ quality = 1; price = 20000; };
	class NLD_MX_C_W								{ quality = 1; price = 20000; };
	class SMG_03_black								{ quality = 1; price = 50000; };
	class SMG_03_camo								{ quality = 1; price = 50000; };
	class SMG_03_khaki								{ quality = 1; price = 50000; };
	class SMG_03_hex								{ quality = 1; price = 50000; };
	class SMG_03C_black								{ quality = 1; price = 50000; };
	class SMG_03C_camo								{ quality = 1; price = 50000; };
	class SMG_03C_khaki								{ quality = 1; price = 50000; };
	class SMG_03C_hex								{ quality = 1; price = 50000; };
	class 50Rnd_570x28_SMG_03						{ quality = 1; price = 1000; };