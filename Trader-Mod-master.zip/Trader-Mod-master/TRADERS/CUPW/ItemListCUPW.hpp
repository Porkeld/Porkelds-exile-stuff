	///////////////////////////////////////////////////////////////////////////////
	// CUP WEAPONS
	// Thanks to Bob_the_K for update and dupe classes in exile
	///////////////////////////////////////////////////////////////////////////////

	///////////////////////////////////////////////////////////////////////////////
	// Assault rifle
	///////////////////////////////////////////////////////////////////////////////
	class CUP_arifle_AK107									{ quality = 1; price = 400; };
	class CUP_arifle_AK107_GL								{ quality = 1; price = 400; };
	class CUP_arifle_AK74									{ quality = 1; price = 400; };
	class CUP_arifle_AK74_GL								{ quality = 1; price = 400; };
	class CUP_arifle_AKM									{ quality = 1; price = 400; };
	class CUP_arifle_AKS									{ quality = 1; price = 400; };
	class CUP_arifle_AKS74									{ quality = 1; price = 400; };
	class CUP_arifle_AKS74U									{ quality = 1; price = 400; };
	class CUP_arifle_AKS_Gold								{ quality = 1; price = 400; };
	class CUP_arifle_CZ805_A1								{ quality = 1; price = 400; };
	class CUP_arifle_CZ805_A2								{ quality = 1; price = 400; };
	class CUP_arifle_CZ805_B								{ quality = 1; price = 400; };
	class CUP_arifle_CZ805_B_GL								{ quality = 1; price = 400; };
	class CUP_arifle_CZ805_GL								{ quality = 1; price = 400; };
	class CUP_arifle_FNFAL									{ quality = 1; price = 400; };
	class CUP_arifle_FNFAL_railed							{ quality = 1; price = 400; };
	class CUP_arifle_G36A									{ quality = 1; price = 400; };
	class CUP_arifle_G36A_camo								{ quality = 1; price = 400; };
	class CUP_arifle_G36C									{ quality = 1; price = 400; };
	class CUP_arifle_G36C_camo								{ quality = 1; price = 400; };
	class CUP_arifle_G36K									{ quality = 1; price = 400; };
	class CUP_arifle_G36K_camo								{ quality = 1; price = 400; };
	class CUP_arifle_L85A2									{ quality = 1; price = 400; };
	class CUP_arifle_L85A2_GL								{ quality = 1; price = 400; };
	class CUP_arifle_L86A2									{ quality = 1; price = 400; };
	class CUP_arifle_M16A2									{ quality = 1; price = 400; };
	class CUP_arifle_M16A2_GL								{ quality = 1; price = 400; };
	class CUP_arifle_M16A4GL								{ quality = 1; price = 400; };
	class CUP_arifle_M16A4_Base								{ quality = 1; price = 400; };
	class CUP_arifle_M16A4_GL								{ quality = 1; price = 400; };
	class CUP_arifle_M4A1									{ quality = 1; price = 400; };
	class CUP_arifle_M4A1_BUIS_GL							{ quality = 1; price = 400; };
	class CUP_arifle_M4A1_BUIS_camo_GL						{ quality = 1; price = 400; };
	class CUP_arifle_M4A1_BUIS_desert_GL					{ quality = 1; price = 400; };
	class CUP_arifle_M4A1_black								{ quality = 1; price = 400; };
	class CUP_arifle_M4A1_camo								{ quality = 1; price = 400; };
	class CUP_arifle_M4A1_desert							{ quality = 1; price = 400; };
	class CUP_arifle_MG36									{ quality = 1; price = 400; };
	class CUP_arifle_MG36_camo								{ quality = 1; price = 400; };
	class CUP_arifle_Mk16_CQC								{ quality = 1; price = 400; };
	class CUP_arifle_Mk16_CQC_EGLM							{ quality = 1; price = 400; };
	class CUP_arifle_Mk16_CQC_FG							{ quality = 1; price = 400; };
	class CUP_arifle_Mk16_CQC_SFG							{ quality = 1; price = 400; };
	class CUP_arifle_Mk16_STD								{ quality = 1; price = 400; };
	class CUP_arifle_Mk16_STD_EGLM							{ quality = 1; price = 400; };
	class CUP_arifle_Mk16_STD_FG							{ quality = 1; price = 400; };
	class CUP_arifle_Mk16_STD_SFG							{ quality = 1; price = 400; };
	class CUP_arifle_Mk16_SV								{ quality = 1; price = 400; };
	class CUP_arifle_Mk17_CQC								{ quality = 1; price = 400; };
	class CUP_arifle_Mk17_CQC_EGLM							{ quality = 1; price = 400; };
	class CUP_arifle_Mk17_CQC_FG							{ quality = 1; price = 400; };
	class CUP_arifle_Mk17_CQC_SFG							{ quality = 1; price = 400; };
	class CUP_arifle_Mk17_STD								{ quality = 1; price = 400; };
	class CUP_arifle_Mk17_STD_EGLM							{ quality = 1; price = 400; };
	class CUP_arifle_Mk17_STD_FG							{ quality = 1; price = 400; };
	class CUP_arifle_Mk17_STD_SFG							{ quality = 1; price = 400; };
	class CUP_arifle_Mk20									{ quality = 1; price = 400; };
	class CUP_arifle_RPK74									{ quality = 1; price = 400; };
	class CUP_arifle_Sa58P									{ quality = 1; price = 400; };
	class CUP_arifle_Sa58P_des								{ quality = 1; price = 400; };
	class CUP_arifle_Sa58RIS1								{ quality = 1; price = 400; };
	class CUP_arifle_Sa58RIS2								{ quality = 1; price = 400; };
	class CUP_arifle_Sa58RIS2_camo							{ quality = 1; price = 400; };
	class CUP_arifle_Sa58V									{ quality = 1; price = 400; };
	class CUP_arifle_Sa58V_camo								{ quality = 1; price = 400; };
	class CUP_arifle_XM8_Carbine							{ quality = 1; price = 400; };
	class CUP_arifle_XM8_Carbine_FG							{ quality = 1; price = 400; };
	class CUP_arifle_XM8_Carbine_GL							{ quality = 1; price = 400; };
	class CUP_arifle_XM8_Compact							{ quality = 1; price = 400; };
	class CUP_arifle_XM8_Compact_Rail						{ quality = 1; price = 400; };
	class CUP_arifle_XM8_Railed								{ quality = 1; price = 400; };
	class CUP_arifle_xm8_SAW								{ quality = 1; price = 400; };
	class CUP_arifle_xm8_sharpshooter						{ quality = 1; price = 400; };
	class CUP_sgun_AA12										{ quality = 1; price = 400; };
	class CUP_sgun_M1014									{ quality = 1; price = 400; };
	class CUP_sgun_Saiga12K									{ quality = 1; price = 400; };
/*	class CUP_arifle_AK107_GL_kobra							{ quality = 1; price = 400; }; // Dupe bug
	class CUP_arifle_AK107_GL_pso							{ quality = 1; price = 400; }; // Dupe bug
	class CUP_arifle_AK107_kobra							{ quality = 1; price = 400; }; // Dupe bug
	class CUP_arifle_AK107_pso								{ quality = 1; price = 400; }; // Dupe bug
	class CUP_arifle_AK74_GL_kobra							{ quality = 1; price = 400; }; // Dupe bug
	class CUP_arifle_AKS74UN_kobra_snds						{ quality = 1; price = 400; }; // Dupe bug
	class CUP_arifle_AKS74_Goshawk							{ quality = 1; price = 400; }; // Dupe bug
	class CUP_arifle_AKS74_NSPU								{ quality = 1; price = 400; }; // Dupe bug
	class CUP_arifle_CZ805B_GL_ACOG_Laser					{ quality = 1; price = 400; }; // Dupe bug
	class CUP_arifle_CZ805_A1_Aco_Laser						{ quality = 1; price = 400; }; // Dupe bug
	class CUP_arifle_CZ805_A1_Holo_Laser					{ quality = 1; price = 400; }; // Dupe bug
	class CUP_arifle_CZ805_A1_MRCO_Laser					{ quality = 1; price = 400; }; // Dupe bug
	class CUP_arifle_CZ805_A1_ZDDot_Laser					{ quality = 1; price = 400; }; // Dupe bug
	class CUP_arifle_CZ805_A2_Aco_Laser						{ quality = 1; price = 400; }; // Dupe bug
	class CUP_arifle_CZ805_A2_Holo_Laser					{ quality = 1; price = 400; }; // Dupe bug
	class CUP_arifle_CZ805_A2_MRCO_Laser					{ quality = 1; price = 400; }; // Dupe bug
	class CUP_arifle_CZ805_A2_ZDDot_Flashlight_Snds			{ quality = 1; price = 400; }; // Dupe bug
	class CUP_arifle_CZ805_GL_Hamr_Laser					{ quality = 1; price = 400; }; // Dupe bug
	class CUP_arifle_CZ805_GL_ZDDot_Laser					{ quality = 1; price = 400; }; // Dupe bug
	class CUP_arifle_FNFAL_ANPVS4							{ quality = 1; price = 400; }; // Dupe bug
	class CUP_arifle_G36C_camo_holo_snds					{ quality = 1; price = 400; }; // Dupe bug
	class CUP_arifle_G36C_holo_snds							{ quality = 1; price = 400; }; // Dupe bug
	class CUP_arifle_L85A2_ACOG_Laser						{ quality = 1; price = 400; }; // Dupe bug
	class CUP_arifle_L85A2_CWS_Laser						{ quality = 1; price = 400; }; // Dupe bug
	class CUP_arifle_L85A2_GL_ACOG_Laser					{ quality = 1; price = 400; }; // Dupe bug
	class CUP_arifle_L85A2_GL_Holo_laser					{ quality = 1; price = 400; }; // Dupe bug
	class CUP_arifle_L85A2_GL_SUSAT_Laser					{ quality = 1; price = 400; }; // Dupe bug
	class CUP_arifle_L85A2_Holo_laser						{ quality = 1; price = 400; }; // Dupe bug
	class CUP_arifle_L85A2_SUSAT_Laser						{ quality = 1; price = 400; }; // Dupe bug
	class CUP_arifle_L86A2_ACOG								{ quality = 1; price = 400; }; // Dupe bug
	class CUP_arifle_M16A4_ACOG_Laser						{ quality = 1; price = 400; }; // Dupe bug
	class CUP_arifle_M16A4_Aim_Laser						{ quality = 1; price = 400; }; // Dupe bug
	class CUP_arifle_M16A4_GL_ACOG_Laser					{ quality = 1; price = 400; }; // Dupe bug
	class CUP_arifle_M4A1_Aim								{ quality = 1; price = 400; }; // Dupe bug
	class CUP_arifle_M4A1_GL_ACOG_Flashlight				{ quality = 1; price = 400; }; // Dupe bug
	class CUP_arifle_M4A1_GL_Holo_Flashlight				{ quality = 1; price = 400; }; // Dupe bug
	class CUP_arifle_M4A1_camo_AIM_snds						{ quality = 1; price = 400; }; // Dupe bug
	class CUP_arifle_M4A1_camo_Aim							{ quality = 1; price = 400; }; // Dupe bug
	class CUP_arifle_M4A1_camo_GL_Holo_Flashlight			{ quality = 1; price = 400; }; // Dupe bug
	class CUP_arifle_M4A1_camo_GL_Holo_Flashlight_Snds		{ quality = 1; price = 400; }; // Dupe bug
	class CUP_arifle_M4A3_desert_Aim_Flashlight				{ quality = 1; price = 400; }; // Dupe bug
	class CUP_arifle_M4A3_desert_GL_ACOG_Laser				{ quality = 1; price = 400; }; // Dupe bug
	class CUP_arifle_Mk16_CQC_EGLM_Holo_Laser_mfsup			{ quality = 1; price = 400; }; // Dupe bug
	class CUP_arifle_Mk16_CQC_FG_Aim_Laser_snds				{ quality = 1; price = 400; }; // Dupe bug
	class CUP_arifle_Mk16_CQC_SFG_Holo						{ quality = 1; price = 400; }; // Dupe bug
	class CUP_arifle_Mk16_STD_EGLM_ACOG_Laser				{ quality = 1; price = 400; }; // Dupe bug
	class CUP_arifle_Mk16_STD_EGLM_ANPAS13c1_Laser_mfsup    { quality = 1; price = 400; }; // Dupe bug
	class CUP_arifle_Mk16_STD_FG_Holo_Laser					{ quality = 1; price = 400; }; // Dupe bug
	class CUP_arifle_Mk16_STD_FG_LeupoldMk4CQT_Laser		{ quality = 1; price = 400; }; // Dupe bug
	class CUP_arifle_Mk17_CQC_SFG_Aim_mfsup					{ quality = 1; price = 400; }; // Dupe bug
	class CUP_arifle_Mk17_STD_EGL_ElcanSpecter_Laser		{ quality = 1; price = 400; }; // Dupe bug
	class CUP_arifle_Mk17_STD_FG_ANPAS13c1_Laser_Snds		{ quality = 1; price = 400; }; // Dupe bug
	class CUP_arifle_Mk17_STD_FG_Aim_Laser_snds				{ quality = 1; price = 400; }; // Dupe bug
	class CUP_arifle_Mk20_LeupoldMk4MRT						{ quality = 1; price = 400; }; // Dupe bug
	class CUP_arifle_Mk20_SB11420_snds						{ quality = 1; price = 400; }; // Dupe bug
	class CUP_arifle_Sa58RIS1_Aco_Laser						{ quality = 1; price = 400; }; // Dupe bug
	class CUP_arifle_Sa58RIS1_camo_Aco_Laser				{ quality = 1; price = 400; }; // Dupe bug
	class CUP_arifle_Sa58RIS1_des							{ quality = 1; price = 400; };	//may be broken
	class CUP_arifle_Sa58RIS2_Arco_Laser					{ quality = 1; price = 400; }; // Dupe bug
	class CUP_arifle_Sa58RIS2_camo_Arco_Laser				{ quality = 1; price = 400; }; // Dupe bug
	class CUP_arifle_Sa58V_ACOG_Laser						{ quality = 1; price = 400; }; // Dupe bug
	class CUP_arifle_Sa58V_Aim_Laser						{ quality = 1; price = 400; }; // Dupe bug
	class CUP_arifle_XM8_Compact_Holo_Flashlight			{ quality = 1; price = 400; }; // Dupe bug
	class CUP_arifle_XM8_Railed_ANPAS13c1_Laser				{ quality = 1; price = 400; }; // Dupe bug
	class CUP_arifle_XM8_Railed_ANPAS13c1_Laser_snds		{ quality = 1; price = 400; }; // Dupe bug
	class CUP_arifle_XM8_Railed_Holo_Laser_snds				{ quality = 1; price = 400; }; // Dupe bug
	class CUP_arifle_ksvk_PSO3								{ quality = 1; price = 400; }; // Dupe bug */

	///////////////////////////////////////////////////////////////////////////////
	// Hand Guns
	///////////////////////////////////////////////////////////////////////////////
	class CUP_hgun_Colt1911									{ quality = 1; price = 200; };
	class CUP_hgun_Compact									{ quality = 1; price = 200; };
	class CUP_hgun_Duty										{ quality = 1; price = 200; };
	class CUP_hgun_Glock17									{ quality = 1; price = 200; };
	class CUP_hgun_M9										{ quality = 1; price = 200; };
	class CUP_hgun_Makarov									{ quality = 1; price = 200; };
	class CUP_hgun_MicroUzi									{ quality = 1; price = 200; };
	class CUP_hgun_PB6P9									{ quality = 1; price = 200; };
	class CUP_hgun_Phantom									{ quality = 1; price = 200; };
	class CUP_hgun_SA61										{ quality = 1; price = 200; };
	class CUP_hgun_TaurusTracker455							{ quality = 1; price = 200; };
	class CUP_hgun_TaurusTracker455_gold					{ quality = 1; price = 200; };
/*	class CUP_hgun_Colt1911_snds							{ quality = 1; price = 200; }; // Dupe bug
	class CUP_hgun_Duty_M3X									{ quality = 1; price = 200; }; // Dupe bug
	class CUP_hgun_M9_snds									{ quality = 1; price = 200; }; // Dupe bug
	class CUP_hgun_MicroUzi_snds							{ quality = 1; price = 200; }; // Dupe bug
	class CUP_hgun_PB6P9_snds								{ quality = 1; price = 200; }; // Dupe bug
	class CUP_hgun_Phantom_Flashlight						{ quality = 1; price = 200; }; // Dupe bug
	class CUP_hgun_Phantom_Flashlight_snds					{ quality = 1; price = 200; }; // Dupe bug
	class CUP_hgun_glock17_flashlight						{ quality = 1; price = 200; }; // Dupe bug
	class CUP_hgun_glock17_flashlight_snds					{ quality = 1; price = 200; }; // Dupe bug
	class CUP_hgun_glock17_snds								{ quality = 1; price = 200; }; // Dupe bug */

	///////////////////////////////////////////////////////////////////////////////
	// Light Machine Gun
	///////////////////////////////////////////////////////////////////////////////
	class CUP_lmg_L110A1									{ quality = 1; price = 300; };
	class CUP_lmg_L7A2										{ quality = 1; price = 300; };
	class CUP_lmg_M240										{ quality = 1; price = 300; };
	class CUP_lmg_M249										{ quality = 1; price = 300; };
	class CUP_lmg_M249_para									{ quality = 1; price = 300; };
	class CUP_lmg_Mk48_des									{ quality = 1; price = 300; };
	class CUP_lmg_Mk48_wdl									{ quality = 1; price = 300; };
	class CUP_lmg_PKM										{ quality = 1; price = 300; };
	class CUP_lmg_Pecheneg									{ quality = 1; price = 300; };
	class CUP_lmg_UK59										{ quality = 1; price = 300; };
/*	class CUP_lmg_L110A1_Aim_Laser							{ quality = 1; price = 300; }; // Dupe bug
	class CUP_lmg_M240_ElcanM143							{ quality = 1; price = 300; }; // Dupe bug
	class CUP_lmg_M249_ANPAS13c2_Laser						{ quality = 1; price = 300; }; // Dupe bug
	class CUP_lmg_M249_ElcanM145_Laser						{ quality = 1; price = 300; }; // Dupe bug
	class CUP_lmg_M249_Laser								{ quality = 1; price = 300; }; // Dupe bug
	class CUP_lmg_M60A4										{ quality = 1; price = 300; }; // Dupe bug
	class CUP_lmg_Mk48_des_Aim_Laser						{ quality = 1; price = 300; }; // Dupe bug
	class CUP_lmg_Mk48_wdl_Aim_Laser						{ quality = 1; price = 300; }; // Dupe bug
	class CUP_lmg_Pecheneg_PScope							{ quality = 1; price = 300; }; // Dupe bug */

	///////////////////////////////////////////////////////////////////////////////
	// Sub Machine Gun
	///////////////////////////////////////////////////////////////////////////////
	class CUP_smg_EVO										{ quality = 1; price = 250; };
	class CUP_smg_MP5A5										{ quality = 1; price = 200; };
	class CUP_smg_MP5SD6									{ quality = 1; price = 250; };
	class CUP_smg_bizon										{ quality = 1; price = 200; };
/*	class CUP_smg_EVO_MRad_Flashlight						{ quality = 1; price = 250; }; // Dupe bug
	class CUP_smg_EVO_MRad_Flashlight_Snds					{ quality = 1; price = 250; }; // Dupe bug
	class CUP_smg_bizon_snds								{ quality = 1; price = 200; }; // Dupe bug */

	///////////////////////////////////////////////////////////////////////////////
	//	Sniper Rifle
	///////////////////////////////////////////////////////////////////////////////
	class CUP_srifle_AS50									{ quality = 1; price = 1500; };
	class CUP_srifle_AWM_des								{ quality = 1; price = 1500; };
	class CUP_srifle_AWM_wdl								{ quality = 1; price = 1500; };
	class CUP_srifle_CZ550									{ quality = 1; price = 1500; };
	class CUP_srifle_CZ750									{ quality = 1; price = 1500; };
	class CUP_srifle_DMR									{ quality = 1; price = 1500; };
	class CUP_srifle_LeeEnfield								{ quality = 1; price = 1500; };
	class CUP_srifle_M107_Base								{ quality = 1; price = 1500; };
	class CUP_srifle_M110									{ quality = 1; price = 1500; };
	class CUP_srifle_M14									{ quality = 1; price = 1500; };
	class CUP_srifle_M24_des								{ quality = 1; price = 1500; };
	class CUP_srifle_M24_wdl								{ quality = 1; price = 1500; };
	class CUP_srifle_M40A3									{ quality = 1; price = 1500; };
	class CUP_srifle_Mk12SPR								{ quality = 1; price = 1500; };
	class CUP_srifle_SVD									{ quality = 1; price = 1500; };
	class CUP_srifle_SVD_des								{ quality = 1; price = 1500; };
	class CUP_srifle_VSSVintorez							{ quality = 1; price = 1500; };
	class CUP_srifle_ksvk									{ quality = 1; price = 1500; };
/*	class CUP_srifle_AS50_AMPAS13c2							{ quality = 1; price = 1500; }; // Dupe bug
	class CUP_srifle_AS50_SBPMII							{ quality = 1; price = 1500; }; // Dupe bug
	class CUP_srifle_AWM_des_SBPMII							{ quality = 1; price = 1500; }; // Dupe bug
	class CUP_srifle_AWM_wdl_SBPMII							{ quality = 1; price = 1500; }; // Dupe bug
	class CUP_srifle_CZ750_SOS_bipod						{ quality = 1; price = 1500; }; // Dupe bug
	class CUP_srifle_DMR_LeupoldMk4							{ quality = 1; price = 1500; }; // Dupe bug
	class CUP_srifle_M107_ANPAS13c2							{ quality = 1; price = 1500; }; // Dupe bug
	class CUP_srifle_M107_LeupoldVX3						{ quality = 1; price = 1500; }; // Dupe bug
	class CUP_srifle_M110_ANPAS13c2							{ quality = 1; price = 1500; }; // Dupe bug
	class CUP_srifle_M110_ANPVS10							{ quality = 1; price = 1500; }; // Dupe bug
	class CUP_srifle_M15_Aim								{ quality = 1; price = 1500; }; // Dupe bug
	class CUP_srifle_M24_des_LeupoldMk4LRT					{ quality = 1; price = 1500; }; // Dupe bug
	class CUP_srifle_M24_ghillie							{ quality = 1; price = 1500; }; // Dupe bug
	class CUP_srifle_M24_wdl_LeupoldMk4LRT					{ quality = 1; price = 1500; }; // Dupe bug
	class CUP_srifle_Mk12SPR_LeupoldM3LR					{ quality = 1; price = 1500; }; // Dupe bug
	class CUP_srifle_SVD_Des_pso							{ quality = 1; price = 1500; }; // Dupe bug
	class CUP_srifle_SVD_NSPU								{ quality = 1; price = 1500; }; // Dupe bug
	class CUP_srifle_SVD_des_ghillie_pso					{ quality = 1; price = 1500; }; // Dupe bug
	class CUP_srifle_SVD_pso								{ quality = 1; price = 1500; }; // Dupe bug
	class CUP_srifle_SVD_wdl_ghillie						{ quality = 1; price = 1500; }; // Dupe bug
	class CUP_srifle_VSSVintorez_pso						{ quality = 1; price = 1500; }; // Dupe bug */

    ///////////////////////////////////////////////////////////////////////////////
	//	Grenade Launchers
	///////////////////////////////////////////////////////////////////////////////
	class CUP_glaunch_6G30									{ quality = 1; price = 1000; };
	class CUP_glaunch_M32									{ quality = 1; price = 1000; };
	class CUP_glaunch_M79									{ quality = 1; price = 1000; };
	class CUP_glaunch_Mk13									{ quality = 1; price = 1000; };

	///////////////////////////////////////////////////////////////////////////////
	//  Launchers
	///////////////////////////////////////////////////////////////////////////////
/*	class CUP_launch_9K32Strela								{ quality = 1; price = 2000; }; // Dupe bug
	class CUP_launch_FIM92Stinger							{ quality = 1; price = 2000; }; // Dupe bug
	class CUP_launch_Igla									{ quality = 1; price = 2000; }; // Dupe bug
	class CUP_launch_Javelin								{ quality = 1; price = 2000; }; // Dupe bug
	class CUP_launch_M136									{ quality = 1; price = 2000; }; // Dupe bug
	class CUP_launch_M47									{ quality = 1; price = 2000; }; // Dupe bug
	class CUP_launch_MAAWS									{ quality = 1; price = 2000; }; // Dupe bug
	class CUP_launch_MAAWS_Scope							{ quality = 1; price = 2000; }; // Dupe bug
	class CUP_launch_Metis									{ quality = 1; price = 2000; }; // Dupe bug
	class CUP_launch_Mk153Mod0								{ quality = 1; price = 2000; }; // Dupe bug
	class CUP_launch_Mk153Mod0_SMAWOptics					{ quality = 1; price = 2000; }; // Dupe bug
	class CUP_launch_NLAW									{ quality = 1; price = 2000; }; // Dupe bug
	class CUP_launch_RPG18									{ quality = 1; price = 2000; }; // Dupe bug
	class CUP_launch_RPG7V									{ quality = 1; price = 2000; }; // Dupe bug */

    ///////////////////////////////////////////////////////////////////////////////
	//  Optic Attachment
	///////////////////////////////////////////////////////////////////////////////
	class CUP_optic_ACOG									{ quality = 1; price = 50; };
	class CUP_optic_AN_PAS_13c1								{ quality = 1; price = 50; };
	class CUP_optic_AN_PAS_13c2								{ quality = 1; price = 50; };
	class CUP_optic_AN_PVS_10								{ quality = 1; price = 50; };
	class CUP_optic_AN_PVS_4								{ quality = 1; price = 50; };
	class CUP_optic_CWS										{ quality = 1; price = 50; };
	class CUP_optic_CompM2_Black							{ quality = 1; price = 50; };
	class CUP_optic_CompM2_Desert							{ quality = 1; price = 50; };
	class CUP_optic_CompM2_Woodland							{ quality = 1; price = 50; };
	class CUP_optic_CompM2_Woodland2						{ quality = 1; price = 50; };
	class CUP_optic_CompM4									{ quality = 1; price = 50; };
	class CUP_optic_ELCAN_SpecterDR							{ quality = 1; price = 50; };
	class CUP_optic_ElcanM145								{ quality = 1; price = 50; };
	class CUP_optic_Eotech533								{ quality = 1; price = 50; };
	class CUP_optic_GOSHAWK									{ quality = 1; price = 50; };
	class CUP_optic_HoloBlack								{ quality = 1; price = 50; };
	class CUP_optic_HoloDesert								{ quality = 1; price = 50; };
	class CUP_optic_HoloWdl									{ quality = 1; price = 50; };
	class CUP_optic_Kobra									{ quality = 1; price = 50; };
	class CUP_optic_LeupoldM3LR								{ quality = 1; price = 50; };
	class CUP_optic_LeupoldMk4								{ quality = 1; price = 50; };
	class CUP_optic_LeupoldMk4_10x40_LRT_Desert				{ quality = 1; price = 50; };
	class CUP_optic_LeupoldMk4_10x40_LRT_Woodland			{ quality = 1; price = 50; };
	class CUP_optic_LeupoldMk4_CQ_T							{ quality = 1; price = 50; };
	class CUP_optic_LeupoldMk4_MRT_tan						{ quality = 1; price = 50; };
	class CUP_optic_Leupold_VX3								{ quality = 1; price = 50; };
	class CUP_optic_MAAWS_Scope								{ quality = 1; price = 50; };
	class CUP_optic_MRad									{ quality = 1; price = 50; };
	class CUP_optic_NSPU									{ quality = 1; price = 50; };
	class CUP_optic_PSO_1									{ quality = 1; price = 50; };
	class CUP_optic_PSO_3									{ quality = 1; price = 50; };
	class CUP_optic_PechenegScope							{ quality = 1; price = 50; };
	class CUP_optic_RCO										{ quality = 1; price = 50; };
	class CUP_optic_RCO_desert								{ quality = 1; price = 50; };
	class CUP_optic_SB_11_4x20_PM							{ quality = 1; price = 50; };
	class CUP_optic_SMAW_Scope								{ quality = 1; price = 50; };
	class CUP_optic_SUSAT									{ quality = 1; price = 50; };
	class CUP_optic_TrijiconRx01_black						{ quality = 1; price = 50; };
	class CUP_optic_TrijiconRx01_desert						{ quality = 1; price = 50; };
	class CUP_optic_ZDDot									{ quality = 1; price = 50; };

    ///////////////////////////////////////////////////////////////////////////////
	//  Muzzle Attachment
	///////////////////////////////////////////////////////////////////////////////
	class CUP_muzzle_Bizon									{ quality = 1; price = 20; };
	class CUP_muzzle_PB6P9									{ quality = 1; price = 20; };
	class CUP_muzzle_PBS4									{ quality = 1; price = 20; };
	class CUP_muzzle_mfsup_SCAR_H							{ quality = 1; price = 20; };
	class CUP_muzzle_mfsup_SCAR_L							{ quality = 1; price = 20; };
	class CUP_muzzle_snds_AWM								{ quality = 1; price = 20; };
	class CUP_muzzle_snds_G36_black							{ quality = 1; price = 20; };
	class CUP_muzzle_snds_G36_desert						{ quality = 1; price = 20; };
	class CUP_muzzle_snds_L85								{ quality = 1; price = 20; };
	class CUP_muzzle_snds_M110								{ quality = 1; price = 20; };
	class CUP_muzzle_snds_M14								{ quality = 1; price = 20; };
	class CUP_muzzle_snds_M16								{ quality = 1; price = 20; };
	class CUP_muzzle_snds_M16_camo							{ quality = 1; price = 20; };
	class CUP_muzzle_snds_M9								{ quality = 1; price = 20; };
	class CUP_muzzle_snds_MicroUzi							{ quality = 1; price = 20; };
	class CUP_muzzle_snds_SCAR_H							{ quality = 1; price = 20; };
	class CUP_muzzle_snds_SCAR_L							{ quality = 1; price = 20; };
	class CUP_muzzle_snds_XM8								{ quality = 1; price = 20; };

    ///////////////////////////////////////////////////////////////////////////////
	//  Ammo
	///////////////////////////////////////////////////////////////////////////////

	//// Shotgun
	class CUP_20Rnd_B_AA12_74Slug							{ quality = 1; price = 10; };
	class CUP_20Rnd_B_AA12_HE								{ quality = 1; price = 10; };
	class CUP_20Rnd_B_AA12_Pellets							{ quality = 1; price = 10; };
	class CUP_8Rnd_B_Beneli_74Slug							{ quality = 1; price = 10; };
	class CUP_8Rnd_B_Saiga12_74Slug_M						{ quality = 1; price = 10; };

    //// Launcher
	class CUP_1Rnd_HEDP_M203								{ quality = 1; price = 50; };
	class CUP_1Rnd_HE_M203									{ quality = 1; price = 50; };
	class CUP_1Rnd_SmokeGreen_M203							{ quality = 1; price = 50; };
	class CUP_1Rnd_SmokeRed_M203							{ quality = 1; price = 50; };
	class CUP_1Rnd_SmokeYellow_M203							{ quality = 1; price = 50; };
	class CUP_1Rnd_Smoke_M203								{ quality = 1; price = 50; };
	class CUP_6Rnd_FlareGreen_M203							{ quality = 1; price = 50; };
	class CUP_6Rnd_FlareRed_M203							{ quality = 1; price = 50; };
	class CUP_6Rnd_FlareWhite_M203							{ quality = 1; price = 50; };
	class CUP_6Rnd_FlareYellow_M203							{ quality = 1; price = 50; };
	class CUP_6Rnd_HE_M203									{ quality = 1; price = 50; };
	class CUP_6Rnd_SmokeGreen_M203							{ quality = 1; price = 50; };
	class CUP_6Rnd_SmokeRed_M203							{ quality = 1; price = 50; };
	class CUP_6Rnd_SmokeYellow_M203							{ quality = 1; price = 50; };
	class CUP_6Rnd_Smoke_M203								{ quality = 1; price = 50; };
	class CUP_AT13_M										{ quality = 1; price = 1000; };
	class CUP_Dragon_EP1_M									{ quality = 1; price = 1000; };
	class CUP_FlareGreen_M203								{ quality = 1; price = 50; };
	class CUP_FlareRed_M203									{ quality = 1; price = 50; };
	class CUP_FlareWhite_M203								{ quality = 1; price = 50; };
	class CUP_FlareYellow_M203								{ quality = 1; price = 50; };
	class CUP_Igla_M										{ quality = 1; price = 1000; };
	class CUP_Javelin_M										{ quality = 1; price = 1000; };
	class CUP_M136_M										{ quality = 1; price = 1000; };
	class CUP_MAAWS_HEAT_M									{ quality = 1; price = 1000; };
	class CUP_MAAWS_HEDP_M									{ quality = 1; price = 1000; };
	class CUP_NLAW_M										{ quality = 1; price = 1000; };
	class CUP_OG7_M											{ quality = 1; price = 1000; };
	class CUP_PG7VL_M										{ quality = 1; price = 1000; };
	class CUP_PG7VR_M										{ quality = 1; price = 1000; };
	class CUP_PG7V_M										{ quality = 1; price = 1000; };
	class CUP_RPG18_M										{ quality = 1; price = 1000; };
	class CUP_SMAW_HEAA_M									{ quality = 1; price = 1000; };
	class CUP_SMAW_HEDP_M									{ quality = 1; price = 1000; };
	class CUP_Stinger_M										{ quality = 1; price = 1000; };
	class CUP_Strela_2_M									{ quality = 1; price = 1000; };

    //// Handgun
	class CUP_10Rnd_9x19_Compact							{ quality = 1; price = 8; };
	class CUP_15Rnd_9x19_M9									{ quality = 1; price = 8; };
	class CUP_17Rnd_9x19_glock17							{ quality = 1; price = 8; };
	class CUP_18Rnd_9x19_Phantom							{ quality = 1; price = 8; };
	class CUP_6Rnd_45ACP_M									{ quality = 1; price = 8; };
	class CUP_7Rnd_45ACP_1911								{ quality = 1; price = 8; };
	class CUP_8Rnd_9x18_MakarovSD_M							{ quality = 1; price = 8; };
	class CUP_8Rnd_9x18_Makarov_M							{ quality = 1; price = 8; };

    //// LMG
	class CUP_100Rnd_TE4_Green_Tracer_556x45_M249			{ quality = 1; price = 50; };
	class CUP_100Rnd_TE4_LRT4_White_Tracer_762x51_Belt_M    { quality = 1; price = 50; };
	class CUP_100Rnd_TE4_Red_Tracer_556x45_M249				{ quality = 1; price = 50; };
	class CUP_100Rnd_TE4_Yellow_Tracer_556x45_M249			{ quality = 1; price = 50; };
	class CUP_200Rnd_TE1_Red_Tracer_556x45_M249				{ quality = 1; price = 50; };
	class CUP_200Rnd_TE4_Green_Tracer_556x45_L110A1			{ quality = 1; price = 50; };
	class CUP_200Rnd_TE4_Red_Tracer_556x45_L110A1			{ quality = 1; price = 50; };
	class CUP_200Rnd_TE4_Red_Tracer_556x45_M249				{ quality = 1; price = 50; };
	class CUP_200Rnd_TE4_Yellow_Tracer_556x45_L110A1		{ quality = 1; price = 50; };
	class CUP_200Rnd_TE4_Yellow_Tracer_556x45_M249			{ quality = 1; price = 50; };
	class CUP_50Rnd_UK59_762x54R_Tracer						{ quality = 1; price = 50; };

    //// SMG
	class CUP_20Rnd_B_765x17_Ball_M							{ quality = 1; price = 10; };
	class CUP_30Rnd_9x19_EVO								{ quality = 1; price = 10; };
	class CUP_30Rnd_9x19_MP5								{ quality = 1; price = 10; };
	class CUP_30Rnd_9x19_UZI								{ quality = 1; price = 10; };
	class CUP_64Rnd_9x19_Bizon_M							{ quality = 1; price = 20; };
	class CUP_64Rnd_Green_Tracer_9x19_Bizon_M				{ quality = 1; price = 20; };
	class CUP_64Rnd_Red_Tracer_9x19_Bizon_M					{ quality = 1; price = 20; };
	class CUP_64Rnd_White_Tracer_9x19_Bizon_M				{ quality = 1; price = 20; };
	class CUP_64Rnd_Yellow_Tracer_9x19_Bizon_M				{ quality = 1; price = 20; };

    //// Sniper
	class CUP_10Rnd_127x99_m107								{ quality = 1; price = 10; };
	class CUP_10Rnd_762x51_CZ750							{ quality = 1; price = 10; };
	class CUP_10Rnd_762x51_CZ750_Tracer						{ quality = 1; price = 10; };
	class CUP_10Rnd_762x54_SVD_M							{ quality = 1; price = 10; };
	class CUP_10Rnd_9x39_SP5_VSS_M							{ quality = 1; price = 10; };
	class CUP_10x_303_M										{ quality = 1; price = 10; };
	class CUP_20Rnd_762x51_B_M110							{ quality = 1; price = 10; };
	class CUP_20Rnd_9x39_SP5_VSS_M							{ quality = 1; price = 10; };
	class CUP_20Rnd_TE1_Green_Tracer_762x51_M110			{ quality = 1; price = 10; };
	class CUP_20Rnd_TE1_Red_Tracer_762x51_M110				{ quality = 1; price = 10; };
	class CUP_20Rnd_TE1_White_Tracer_762x51_M110			{ quality = 1; price = 10; };
	class CUP_20Rnd_TE1_Yellow_Tracer_762x51_M110			{ quality = 1; price = 10; };
	class CUP_5Rnd_127x108_KSVK_M							{ quality = 1; price = 10; };
	class CUP_5Rnd_127x99_as50_M							{ quality = 1; price = 10; };
	class CUP_5Rnd_762x51_M24								{ quality = 1; price = 10; };
	class CUP_5Rnd_86x70_L115A1								{ quality = 1; price = 10; };
	class CUP_5x_22_LR_17_HMR_M								{ quality = 1; price = 10; };

    //// Assault Rifle
	class CUP_100Rnd_556x45_BetaCMag						{ quality = 1; price = 10; };
	class CUP_100Rnd_TE1_Green_Tracer_556x45_BetaCMag		{ quality = 1; price = 10; };
	class CUP_100Rnd_TE1_Red_Tracer_556x45_BetaCMag			{ quality = 1; price = 10; };
	class CUP_100Rnd_TE1_Yellow_Tracer_556x45_BetaCMag		{ quality = 1; price = 10; };
	class CUP_20Rnd_556x45_Stanag							{ quality = 1; price = 10; };
	class CUP_20Rnd_762x51_B_SCAR							{ quality = 1; price = 10; };
	class CUP_20Rnd_762x51_CZ805B							{ quality = 1; price = 10; };
	class CUP_20Rnd_762x51_DMR								{ quality = 1; price = 10; };
	class CUP_20Rnd_762x51_FNFAL_M							{ quality = 1; price = 10; };
	class CUP_20Rnd_TE1_Green_Tracer_762x51_CZ805B			{ quality = 1; price = 10; };
	class CUP_20Rnd_TE1_Green_Tracer_762x51_DMR				{ quality = 1; price = 10; };
	class CUP_20Rnd_TE1_Green_Tracer_762x51_SCAR			{ quality = 1; price = 10; };
	class CUP_20Rnd_TE1_Red_Tracer_762x51_CZ805B			{ quality = 1; price = 10; };
	class CUP_20Rnd_TE1_Red_Tracer_762x51_DMR				{ quality = 1; price = 10; };
	class CUP_20Rnd_TE1_Red_Tracer_762x51_SCAR				{ quality = 1; price = 10; };
	class CUP_20Rnd_TE1_White_Tracer_762x51_CZ805B			{ quality = 1; price = 10; };
	class CUP_20Rnd_TE1_White_Tracer_762x51_DMR				{ quality = 1; price = 10; };
	class CUP_20Rnd_TE1_White_Tracer_762x51_SCAR			{ quality = 1; price = 10; };
	class CUP_20Rnd_TE1_Yellow_Tracer_762x51_CZ805B			{ quality = 1; price = 10; };
	class CUP_20Rnd_TE1_Yellow_Tracer_762x51_DMR			{ quality = 1; price = 10; };
	class CUP_20Rnd_TE1_Yellow_Tracer_762x51_SCAR			{ quality = 1; price = 10; };
	class CUP_30Rnd_545x39_AK_M								{ quality = 1; price = 10; };
	class CUP_30Rnd_556x45_G36								{ quality = 1; price = 10; };
	class CUP_30Rnd_556x45_Stanag							{ quality = 1; price = 10; };
	class CUP_30Rnd_762x39_AK47_M							{ quality = 1; price = 10; };
	class CUP_30Rnd_Sa58_M									{ quality = 1; price = 10; };
	class CUP_30Rnd_Sa58_M_TracerG							{ quality = 1; price = 10; };
	class CUP_30Rnd_Sa58_M_TracerR							{ quality = 1; price = 10; };
	class CUP_30Rnd_Sa58_M_TracerY							{ quality = 1; price = 10; };
	class CUP_30Rnd_TE1_Green_Tracer_545x39_AK_M			{ quality = 1; price = 10; };
	class CUP_30Rnd_TE1_Green_Tracer_556x45_G36				{ quality = 1; price = 10; };
	class CUP_30Rnd_TE1_Red_Tracer_545x39_AK_M				{ quality = 1; price = 10; };
	class CUP_30Rnd_TE1_Red_Tracer_556x45_G36				{ quality = 1; price = 10; };
	class CUP_30Rnd_TE1_White_Tracer_545x39_AK_M			{ quality = 1; price = 10; };
	class CUP_30Rnd_TE1_Yellow_Tracer_545x39_AK_M			{ quality = 1; price = 10; };
	class CUP_30Rnd_TE1_Yellow_Tracer_556x45_G36			{ quality = 1; price = 10; };
	class CUP_75Rnd_TE4_LRT4_Green_Tracer_545x39_RPK_M		{ quality = 1; price = 10; };
