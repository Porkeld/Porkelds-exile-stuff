	///////////////////////////////////////////////////////////////////////////////
	// Building Supplies
	///////////////////////////////////////////////////////////////////////////////
	//class Exile_Item_WoodDrawBridgeKit					{ quality = 1; price = 750; };
	class Exile_Item_ConcreteDoorwayKit					{ quality = 3; price = 2200; };
	class Exile_Item_ConcreteDrawBridgeKit         		{ quality = 3; price = 2200; };
	class Exile_Item_ConcreteFloorKit           		{ quality = 3; price = 2200; };
	class Exile_Item_ConcreteFloorPortKit       		{ quality = 3; price = 2200; };
	class Exile_Item_ConcreteFloorPortSmallKit         	{ quality = 3; price = 2200; };
	class Exile_Item_ConcreteGateKit            		{ quality = 3; price = 2200; };
	class Exile_Item_ConcreteLadderHatchKit         	{ quality = 3; price = 2200; };
	class Exile_Item_ConcreteStairsKit          		{ quality = 3; price = 2200; };
	class Exile_Item_ConcreteSupportKit         		{ quality = 3; price = 2200; };
	class Exile_Item_ConcreteWallKit            		{ quality = 3; price = 2200; };
	class Exile_Item_MetalHedgehogKit					{ quality = 2; price = 1200; };
	class Exile_Item_MetalLadderDoubleKit				{ quality = 2; price = 1200; };
	class Exile_Item_MetalLadderKit						{ quality = 2; price = 600; };
	class Exile_Item_OldChestKit						{ quality = 1; price = 500; };
	class Exile_Item_WoodDoorKit						{ quality = 1; price = 750; };
	class Exile_Item_WoodDoorwayKit						{ quality = 1; price = 750; };
	class Exile_Item_WoodFloorKit						{ quality = 1; price = 750; };
	class Exile_Item_WoodFloorPortKit					{ quality = 1; price = 750; };
	class Exile_Item_WoodGateKit						{ quality = 1; price = 750; };
	class Exile_Item_WoodLadderHatchKit					{ quality = 1; price = 750; };
	class Exile_Item_WoodStairsKit						{ quality = 1; price = 750; };
	class Exile_Item_WoodSupportKit						{ quality = 1; price = 500; };
	class Exile_Item_WoodWallHalfKit					{ quality = 1; price = 500; };
	class Exile_Item_WoodWallKit						{ quality = 1; price = 750; };
	class Exile_Item_WoodWindowKit						{ quality = 1; price = 750; };
	class Exile_Item_WorkBenchKit						{ quality = 1; price = 500; };	