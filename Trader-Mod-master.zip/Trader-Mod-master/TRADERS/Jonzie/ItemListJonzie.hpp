	///////////////////////////////////////////////////////////////////////////////
	// Jonzie added to package by [CiC]red_ned http://cic//gaming.co.uk
	// Thanks to XxFri3ndlyxX for providing these files
	///////////////////////////////////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////
	// CARS
	///////////////////////////////////////////////////////////////////////////////
	class Jonzie_30CSL   						    		{ quality = 1; price = 1; };
	class Jonzie_Escalade  						    		{ quality = 1; price = 1; };
	class Jonzie_Curtain_Roadtrain   						{ quality = 1; price = 1; };
	class Jonzie_Curtain   						    		{ quality = 1; price = 1; };
	class Jonzie_Datsun_510				   					{ quality = 1; price = 1; };
	class Jonzie_Datsun_Z432   						        { quality = 1; price = 1; };
	class Jonzie_Viper   						    		{ quality = 1; price = 1; };
	class Jonzie_Flatbed_Roadtrain   						{ quality = 1; price = 1; };
	class Jonzie_Flatbed   						            { quality = 1; price = 1; };
	class Jonzie_Raptor   						    		{ quality = 1; price = 1; };
	class Jonzie_XB				   					        { quality = 1; price = 1; };
	class Jonzie_Transit   						            { quality = 1; price = 1; };
	class Jonzie_Forklift   						        { quality = 1; price = 1; };
	class Jonzie_Ambulance   						    	{ quality = 1; price = 1; };
	class Jonzie_VE   						    	     	{ quality = 1; price = 1; };
	class Jonzie_Highway  						    		{ quality = 1; price = 1; };
	class Jonzie_Ute   						                { quality = 1; price = 1; };
	class Jonzie_Ceed   						    		{ quality = 1; price = 1; };
	class Jonzie_Superliner				   					{ quality = 1; price = 1; };
	class Jonzie_Box_Truck   						        { quality = 1; price = 1; };
	class Jonzie_Flat_Bed   						   		{ quality = 1; price = 1; };
	class Jonzie_Log_Truck   						        { quality = 1; price = 1; };
	class Jonzie_Tanker_Truck   						    { quality = 1; price = 1; };
	class Jonzie_Tow_Truck   						    	{ quality = 1; price = 1; };
	class Jonzie_Quattroporte				   			    { quality = 1; price = 1; };
	class Jonzie_Mini_Cooper   						        { quality = 1; price = 1; };
	class Jonzie_Mini_Cooper_R_spec   				        { quality = 1; price = 1; };
	class Jonzie_Galant   						    	    { quality = 1; price = 1; };
	class Jonzie_STI				   			            { quality = 1; price = 1; };
	class Jonzie_Corolla   						            { quality = 1; price = 1; };
	class Jonzie_Western   				                    { quality = 1; price = 1; };
	class Jonzie_Pallet_Empty   				     	    { quality = 1; price = 1; };
